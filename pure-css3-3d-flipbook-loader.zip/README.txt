A Pen created at CodePen.io. You can find this one at http://codepen.io/joshy/pen/eNvZyN.

 Been experimenting with CSS 3D transforms